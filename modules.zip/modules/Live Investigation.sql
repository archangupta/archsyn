-- Any scheduled batch errors for the last day.
select j.*, e.error_code, e.error_type, e.error_text 
from   jobs j, job_errors e, job_schedules s
where  j.id = e.job_id
and    e.error_type = 'E'
and    s.id = j.jbs_id
and    s.processing_date >= (trunc(sysdate) - 1)
and    j.submission_type = 'SB'     -- scheduled batch
;

-- Check the main finance modules have run ok.
select j.*, e.*
from   jobs j, module_errors e, job_schedules s
where  j.id = e.job_id (+)
and    s.id = j.jbs_id
and    s.processing_date >= (trunc(sysdate) - 1)
and    upper(j.mod_name) in ('CCFPK002.P_POSTING_ROUTINE',
                             'CCFPK103.P_INTEREST_ACCRUAL', 
                             'CCFPK040.P_INSERT_DAILY_SUMMARY', 
                             'CCFPK040.P_INSERT_CF_BALANCES', 
                             'CCFPK040.P_INSERT_DBR_TABLES', 
                             'CCFPK130.P_INSERT_CCFOR031_TABLES')
order by j.id desc;

-- Get the longest running jobs for the last 24 hours.
select (j.finish_date_time - j.start_date_time) * 24 as "RUNTIME IN HOURS", j.id, j.mod_name, j.mod_occurrence, j.status, j.start_date_time, j.finish_date_time
from   jobs j, job_schedules s
where  j.jbs_id = s.id
and    s.processing_date >= (trunc(sysdate) - 1)
and    j.job_id is null
and    (j.finish_date_time - j.start_date_time) * 24 > 2
and    j.submission_type = 'SB'     -- scheduled batch
order by 1 desc nulls last;

-- Check a specific module, so see if the timings are with the normal range
select (j.finish_date_time - j.start_date_time) * 24, j.id, j.mod_name, j.mod_occurrence, j.status, j.start_date_time, j.finish_date_time, j.*
from   jobs j, job_schedules s
where  j.jbs_id = s.id
and    upper(j.mod_name) like 'CCFPK103%'
and    j.job_id is null
and   (j.finish_date_time - j.start_date_time) * 24 > 8
and    s.processing_date >= (trunc(sysdate) - 1)
and    j.submission_type = 'SB'     -- scheduled batch
order by j.start_date_time desc;

-- Check the parameters for a specific job look ok
select * 
from   parameter_values p
where  p.job_id = :p_job_id
order by p.validation_sequence;

-- 
select * 
from   finance_errors e
where  e.last_updated_date_time > (sysdate - 1)
--and    e.mod_name like 'CCFPK034%'
;

select * 
from   xxsl_sync_exceptions s
where  lower(s.triggering_module) = lower('CLAPK162.P_SUB_LP_FEE_PAYMENTS')
order by s.id desc;

-- for modules CCFPK103, CCFPK002 and 
select * 
from   xxsl_job_files f
where  f.job_name like 'CCFPK002%20200526%'
--and    lower(f.text) like '%ORA%'
order by f.job_name desc, f.line_number;

select * 
from   module_dependencies mdp
where  'CCFPK130.P_INSERT_CCFOR031_TABLES' in (mod_name, mod_name_depending)
and    mds_id = 27;

